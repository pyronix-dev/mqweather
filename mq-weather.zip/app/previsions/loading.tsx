// Developed by Omar Rafik (OMX) - omx001@proton.me
export default function Loading() {
  return null
}